using System;

namespace Prosimo.ThermalProperties {
   /// <summary>
   /// As the name of the class indicates this dummy class does nothing
   /// It is created for loading the assembly of ThermalProperties from within the ProsimoUI  
   /// </summary>
   public class Dummy {
   }
}
