using System;
using Prosimo.SubstanceLibrary;

namespace Prosimo.ThermalProperties {
   /// <summary>
   /// Summary description for MoistureProperties.
   /// </summary>
   public class MoistureProperties {
      //private const double r0 = 2501.0;
      //private const double n1 = 0.3298;
      //private const double n2 = 0.38;
      //private const double tc = 647.3;
      //private const double t0 = 273.15;
      private Substance moisture;
      private const double minimumTemperature = 1.0e-10;
      //water properties-------------------
      //Perry's
      /*private const double tc = 647.13;
      private double[] liqCpCoeffs = {2.7637e5, -2.0901e3, 8.125, -1.4116e-2, 9.3701e-6};
      private double[] gasCpCoeffs = {0.3336e5, 0.2679e5, 2.6105e3, 0.089e5, 1169.0};
      private double[] evapHeatCoeffs = {5.2053e7, 0.3199, -0.212, 0.25795};
      private double[] vapPressureCoeffs = {73.649, -7258.2, -7.3037, 4.1653e-6, 2.0};
      private double molarWeight = 18.015; */
      private double criticalTemperature;
      private double[] liqCpCoeffs;
      private double[] gasCpCoeffs;
      private double[] liqDensityCoeffs;
      private double[] evapHeatCoeffs;
      private double[] vapPressureCoeffs;
      private double molarWeight;
      //water properties-------------------

      public MoistureProperties(Substance moisture) {
         this.moisture = moisture;
         ThermalPropsAndCoeffs tpc = moisture.ThermalPropsAndCoeffs;
         criticalTemperature = moisture.CriticalProperties.CriticalTemperature;
         liqCpCoeffs = tpc.LiqCpCoeffs;
         gasCpCoeffs = tpc.GasCpCoeffs;
         liqDensityCoeffs = tpc.LiqDensityCoeffs;
         evapHeatCoeffs = tpc.EvapHeatCoeffs;
         vapPressureCoeffs = tpc.VapPressureCoeffs;
         molarWeight = moisture.MolarWeight;
      }

      public double GetEvaporationHeat(double temperature) {
         if (temperature < minimumTemperature || temperature > criticalTemperature) {
            throw new IllegalVarValueException("Temperature out of range.");
         }
         //double n = n1;
         //if (temperature > 563.15 && temperature <= tc) {
         //   n = n2;
         //}
         //double c = Math.Pow((tc-temperature)/(tc-t0), n);
         //return r0 * Math.Pow((tc-temperature)/(tc-t0), n);
         //this correlation comes from Perry's Chemical Engineers Handbook, 6th edition
         //double tr = temperature/PropConstants.Tc;
         //double tempValue = 0.3199 - 0.212 * tr + 0.25795 * tr * tr;
         //double r = 5.2053e7/18.015 * Math.Pow((1-tr), tempValue);
         //return r;
         double r = ThermalPropCalculator.CalculateEvaporationHeat(temperature, criticalTemperature, evapHeatCoeffs);
         return r / molarWeight;
      }

      public double GetSaturationPressure(double temperature) {
         if (temperature < minimumTemperature || temperature > criticalTemperature) {
            throw new IllegalVarValueException("Temperature out of range");
         }

         double pSaturation = 1.0;

         if (moisture.Name.Equals("Water")) {
            pSaturation = ThermalPropCalculator.CalculateWaterSaturationPressure(temperature);
         }
         else {
            pSaturation = ThermalPropCalculator.CalculateSaturationPressure(temperature, vapPressureCoeffs);
         }

         return pSaturation;
      }

      public double GetSaturationTemperature(double pressure) {
         double temperature = 1.0e-10;
         if (moisture.Name.Equals("Water")) {
            temperature = ThermalPropCalculator.CalculateWaterSaturationTemperature(pressure);
         }
         else {
            temperature = ThermalPropCalculator.CalculateSaturationTemperature(pressure, vapPressureCoeffs);
         }
         return temperature;
      }

      public double GetDensity(double pressure, double temperature) {
         double density = 1;
         if (moisture.Name.Equals("Water")) {
            density = ThermalPropCalculator.CalculateWaterDensity(pressure, temperature);
         }
         else {
            double satTemperature = GetSaturationTemperature(pressure);
            if (temperature < satTemperature) {
               density = ThermalPropCalculator.CalculateLiquidDensity(temperature, liqDensityCoeffs);
            }
            else if (temperature > satTemperature) {
               //density = ThermalPropCalculator.CalculateLiquidDensity(temperature);
               //need to use state equation to calculate state
            }
         }
         return density;
      }

      public double GetSpecificHeatOfLiquid(double temperature) {
         //this correlation comes from Perry's Chemical Engineers Handbook
         //double cp = 2.7637e5 - 2.0901e3 * temperature + 8.125 * temperature * temperature
         //            -1.4116e-2 * Math.Pow(temperature, 3) + 9.3701e-6 * Math.Pow(temperature, 4);
         double cp = ThermalPropCalculator.CalculateLiquidHeatCapacity1(temperature, liqCpCoeffs);
         return cp / molarWeight;
      }

      public double GetMeanSpecificHeatOfLiquid(double t1, double t2) {
         //this correlation comes from Perry's Chemical Engineers Handbook
         //double cp = 2.7637e5 - 2.0901e3 * temperature + 8.125 * temperature * temperature
         //            -1.4116e-2 * Math.Pow(temperature, 3) + 9.3701e-6 * Math.Pow(temperature, 4);
         double cp = ThermalPropCalculator.CalculateMeanLiquidHeatCapacity1(t1, t2, liqCpCoeffs);
         return cp / molarWeight;
      }

      public double GetMeanSpecificHeatOfLiquid(double p, double t1, double t2) {
         double cp;
         if (moisture.Name.Equals("Water")) {
            if (Math.Abs(t1 - t2) > 1.0e-4) {
               cp = ThermalPropCalculator.CalculateWaterMeanHeatCapacity(p, t1, t2);
            }
            else {
               cp = ThermalPropCalculator.CalculateWaterMeanHeatCapacity(p, t1, t1 + 1);
            }
         }
         else {
            cp = ThermalPropCalculator.CalculateMeanLiquidHeatCapacity1(t1, t2, gasCpCoeffs);
            cp = cp / molarWeight;
         }
         return cp;
      }

      public double GetEnthalpy(double p, double t) {
         double h = 0.0;
         if (moisture.Name.Equals("Water")) {
            h = ThermalPropCalculator.CalculateWaterEnthalpy(p, t);
         }
         return h;
      }

      public double GetSpecificHeatOfLiquid() {
         //return 4187.0;
         return GetSpecificHeatOfLiquid(293.15);
      }

      public double GetSpecificHeatOfVapor(double temperature) {
         //return 1880.0;
         double cp = ThermalPropCalculator.CalculateGasHeatCapacity1(temperature, gasCpCoeffs);
         return cp / molarWeight;
      }

      public double GetMeanSpecificHeatOfVapor(double t1, double t2) {
         //return 1880.0;
         double cp;
         if (Math.Abs(t1 - t2) > 1.0e-4) {
            cp = ThermalPropCalculator.CalculateMeanGasHeatCapacity1(t1, t2, gasCpCoeffs);
         }
         else {
            cp = ThermalPropCalculator.CalculateGasHeatCapacity1(t1, gasCpCoeffs);
         }
         return cp / molarWeight;
      }

      public double GetMeanSpecificHeatOfVapor(double p, double t1, double t2) {
         double cp;
         if (moisture.Name.Equals("Water")) {
            if (Math.Abs(t1 - t2) > 1.0e-4) {
               cp = ThermalPropCalculator.CalculateWaterMeanHeatCapacity(p, t1, t2);
            }
            else {
               cp = ThermalPropCalculator.CalculateWaterMeanHeatCapacity(p, t1, t1 + 1);
            }
         }
         else {
            cp = ThermalPropCalculator.CalculateMeanGasHeatCapacity1(t1, t2, gasCpCoeffs);
            cp = cp / molarWeight;
         }
         return cp;
      }

      public double GetSpecificHeatOfVapor() {
         //return 1880.0;
         return GetSpecificHeatOfVapor(293.15);
      }

      //public double GetMolarWeight() {
      //   return molarWeight;
      //}
   }
}