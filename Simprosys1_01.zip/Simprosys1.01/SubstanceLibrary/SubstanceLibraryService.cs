using System;
using System.Collections;

namespace Prosimo.SubstanceLibrary
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
//	public class SubstanceLibraryService 
//   {
//		private static SubstanceLibraryService self;
//      private SubstanceCatalog substanceCatalog;
//
//      private SubstanceLibraryService() {
//		   substanceCatalog = new SubstanceCatalog();
//      }
//
//      public static SubstanceLibraryService GetInstance() {
//         if (self == null) {
//            self = new SubstanceLibraryService();
//         }
//         return self;
//      }
//
//      public SubstanceCatalog GetSubstanceCatalog() {
//         return substanceCatalog;
//      }
//
//      public Substance GetSubstance(string name) {
//         return substanceCatalog.Get(name);
//      }
//	}
}
