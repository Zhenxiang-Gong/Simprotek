using System;       
using Prosimo.SubstanceLibrary;
//using Prosimo.ThermalProperties;

namespace Prosimo.SubstanceLibrary {
   /// <summary>
   /// Summary description for Class1.
   /// </summary>
   /*public interface IMaterialComponent : ICloneable {
      
      //public Object Clone();

      Substance Substance { get; }

      string Name{ get; }

      double GetMassFractionValue();
      
      void SetMassFractionValue(double v);

      double GetMoleFractionValue();

      void SetMoleFractionValue(double v);
   }*/
}
